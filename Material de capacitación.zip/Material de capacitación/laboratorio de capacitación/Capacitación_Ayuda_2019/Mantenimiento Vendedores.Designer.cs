﻿namespace Capacitación_Ayuda_2019
{
    partial class Mantenimiento_Vendedores
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Mantenimiento_Vendedores));
            this.btnGenerarCodigo = new System.Windows.Forms.Button();
            this.Txt_codEmpleado = new System.Windows.Forms.TextBox();
            this.rdb_nodisponible = new System.Windows.Forms.RadioButton();
            this.rdb_disponible = new System.Windows.Forms.RadioButton();
            this.Lbl_estado = new System.Windows.Forms.Label();
            this.Txt_ComisionVendedor = new System.Windows.Forms.TextBox();
            this.Txt_nombreVendedor = new System.Windows.Forms.TextBox();
            this.Txt_apellidoVendedor = new System.Windows.Forms.TextBox();
            this.Lbl_ApellidoV = new System.Windows.Forms.Label();
            this.Txt_cdigoVemdedor = new System.Windows.Forms.TextBox();
            this.Lbl_nombreV = new System.Windows.Forms.Label();
            this.Lbl_codigoV = new System.Windows.Forms.Label();
            this.Lbl_empleado = new System.Windows.Forms.Label();
            this.Lbl_Comision = new System.Windows.Forms.Label();
            this.btn_Ayuda = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnGenerarCodigo
            // 
            this.btnGenerarCodigo.Location = new System.Drawing.Point(479, 114);
            this.btnGenerarCodigo.Name = "btnGenerarCodigo";
            this.btnGenerarCodigo.Size = new System.Drawing.Size(139, 27);
            this.btnGenerarCodigo.TabIndex = 127;
            this.btnGenerarCodigo.Text = "Generar Código";
            this.btnGenerarCodigo.UseVisualStyleBackColor = true;
            // 
            // Txt_codEmpleado
            // 
            this.Txt_codEmpleado.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Txt_codEmpleado.Location = new System.Drawing.Point(278, 283);
            this.Txt_codEmpleado.Name = "Txt_codEmpleado";
            this.Txt_codEmpleado.ReadOnly = true;
            this.Txt_codEmpleado.Size = new System.Drawing.Size(440, 27);
            this.Txt_codEmpleado.TabIndex = 124;
            this.Txt_codEmpleado.Tag = "2";
            // 
            // rdb_nodisponible
            // 
            this.rdb_nodisponible.AutoSize = true;
            this.rdb_nodisponible.BackColor = System.Drawing.Color.Transparent;
            this.rdb_nodisponible.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdb_nodisponible.ForeColor = System.Drawing.Color.DarkCyan;
            this.rdb_nodisponible.Location = new System.Drawing.Point(590, 403);
            this.rdb_nodisponible.Name = "rdb_nodisponible";
            this.rdb_nodisponible.Size = new System.Drawing.Size(134, 23);
            this.rdb_nodisponible.TabIndex = 123;
            this.rdb_nodisponible.TabStop = true;
            this.rdb_nodisponible.Text = "No disponible";
            this.rdb_nodisponible.UseVisualStyleBackColor = false;
            // 
            // rdb_disponible
            // 
            this.rdb_disponible.AutoSize = true;
            this.rdb_disponible.BackColor = System.Drawing.Color.Transparent;
            this.rdb_disponible.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdb_disponible.ForeColor = System.Drawing.Color.DarkCyan;
            this.rdb_disponible.Location = new System.Drawing.Point(278, 403);
            this.rdb_disponible.Name = "rdb_disponible";
            this.rdb_disponible.Size = new System.Drawing.Size(108, 23);
            this.rdb_disponible.TabIndex = 122;
            this.rdb_disponible.TabStop = true;
            this.rdb_disponible.Text = "Disponible";
            this.rdb_disponible.UseVisualStyleBackColor = false;
            // 
            // Lbl_estado
            // 
            this.Lbl_estado.AutoSize = true;
            this.Lbl_estado.BackColor = System.Drawing.Color.Transparent;
            this.Lbl_estado.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl_estado.ForeColor = System.Drawing.Color.DarkCyan;
            this.Lbl_estado.Location = new System.Drawing.Point(68, 405);
            this.Lbl_estado.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Lbl_estado.Name = "Lbl_estado";
            this.Lbl_estado.Size = new System.Drawing.Size(59, 19);
            this.Lbl_estado.TabIndex = 121;
            this.Lbl_estado.Text = "Estado";
            // 
            // Txt_ComisionVendedor
            // 
            this.Txt_ComisionVendedor.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Txt_ComisionVendedor.Location = new System.Drawing.Point(278, 339);
            this.Txt_ComisionVendedor.MaxLength = 3;
            this.Txt_ComisionVendedor.Name = "Txt_ComisionVendedor";
            this.Txt_ComisionVendedor.Size = new System.Drawing.Size(440, 27);
            this.Txt_ComisionVendedor.TabIndex = 117;
            this.Txt_ComisionVendedor.Tag = "3";
            // 
            // Txt_nombreVendedor
            // 
            this.Txt_nombreVendedor.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Txt_nombreVendedor.Location = new System.Drawing.Point(278, 170);
            this.Txt_nombreVendedor.Name = "Txt_nombreVendedor";
            this.Txt_nombreVendedor.ReadOnly = true;
            this.Txt_nombreVendedor.Size = new System.Drawing.Size(440, 27);
            this.Txt_nombreVendedor.TabIndex = 118;
            // 
            // Txt_apellidoVendedor
            // 
            this.Txt_apellidoVendedor.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Txt_apellidoVendedor.Location = new System.Drawing.Point(278, 226);
            this.Txt_apellidoVendedor.Name = "Txt_apellidoVendedor";
            this.Txt_apellidoVendedor.ReadOnly = true;
            this.Txt_apellidoVendedor.Size = new System.Drawing.Size(440, 27);
            this.Txt_apellidoVendedor.TabIndex = 120;
            // 
            // Lbl_ApellidoV
            // 
            this.Lbl_ApellidoV.AutoSize = true;
            this.Lbl_ApellidoV.BackColor = System.Drawing.Color.Transparent;
            this.Lbl_ApellidoV.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl_ApellidoV.ForeColor = System.Drawing.Color.DarkCyan;
            this.Lbl_ApellidoV.Location = new System.Drawing.Point(68, 230);
            this.Lbl_ApellidoV.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Lbl_ApellidoV.Name = "Lbl_ApellidoV";
            this.Lbl_ApellidoV.Size = new System.Drawing.Size(184, 19);
            this.Lbl_ApellidoV.TabIndex = 114;
            this.Lbl_ApellidoV.Text = "Apellido del vendedor";
            // 
            // Txt_cdigoVemdedor
            // 
            this.Txt_cdigoVemdedor.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Txt_cdigoVemdedor.Location = new System.Drawing.Point(278, 114);
            this.Txt_cdigoVemdedor.MaxLength = 11;
            this.Txt_cdigoVemdedor.Name = "Txt_cdigoVemdedor";
            this.Txt_cdigoVemdedor.ReadOnly = true;
            this.Txt_cdigoVemdedor.Size = new System.Drawing.Size(180, 27);
            this.Txt_cdigoVemdedor.TabIndex = 119;
            this.Txt_cdigoVemdedor.Tag = "1";
            // 
            // Lbl_nombreV
            // 
            this.Lbl_nombreV.AutoSize = true;
            this.Lbl_nombreV.BackColor = System.Drawing.Color.Transparent;
            this.Lbl_nombreV.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl_nombreV.ForeColor = System.Drawing.Color.DarkCyan;
            this.Lbl_nombreV.Location = new System.Drawing.Point(68, 174);
            this.Lbl_nombreV.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Lbl_nombreV.Name = "Lbl_nombreV";
            this.Lbl_nombreV.Size = new System.Drawing.Size(182, 19);
            this.Lbl_nombreV.TabIndex = 113;
            this.Lbl_nombreV.Text = "Nombre del vendedor";
            // 
            // Lbl_codigoV
            // 
            this.Lbl_codigoV.AutoSize = true;
            this.Lbl_codigoV.BackColor = System.Drawing.Color.Transparent;
            this.Lbl_codigoV.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl_codigoV.ForeColor = System.Drawing.Color.DarkCyan;
            this.Lbl_codigoV.Location = new System.Drawing.Point(68, 118);
            this.Lbl_codigoV.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Lbl_codigoV.Name = "Lbl_codigoV";
            this.Lbl_codigoV.Size = new System.Drawing.Size(176, 19);
            this.Lbl_codigoV.TabIndex = 112;
            this.Lbl_codigoV.Text = "Codigo del vendedor";
            // 
            // Lbl_empleado
            // 
            this.Lbl_empleado.AutoSize = true;
            this.Lbl_empleado.BackColor = System.Drawing.Color.Transparent;
            this.Lbl_empleado.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl_empleado.ForeColor = System.Drawing.Color.DarkCyan;
            this.Lbl_empleado.Location = new System.Drawing.Point(68, 286);
            this.Lbl_empleado.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Lbl_empleado.Name = "Lbl_empleado";
            this.Lbl_empleado.Size = new System.Drawing.Size(90, 19);
            this.Lbl_empleado.TabIndex = 116;
            this.Lbl_empleado.Text = "Empleado";
            // 
            // Lbl_Comision
            // 
            this.Lbl_Comision.AutoSize = true;
            this.Lbl_Comision.BackColor = System.Drawing.Color.Transparent;
            this.Lbl_Comision.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl_Comision.ForeColor = System.Drawing.Color.DarkCyan;
            this.Lbl_Comision.Location = new System.Drawing.Point(68, 342);
            this.Lbl_Comision.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Lbl_Comision.Name = "Lbl_Comision";
            this.Lbl_Comision.Size = new System.Drawing.Size(193, 19);
            this.Lbl_Comision.TabIndex = 115;
            this.Lbl_Comision.Text = "Porcentaje de Comisión";
            // 
            // btn_Ayuda
            // 
            this.btn_Ayuda.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(193)))), ((int)(((byte)(195)))));
            this.btn_Ayuda.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_Ayuda.BackgroundImage")));
            this.btn_Ayuda.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_Ayuda.Location = new System.Drawing.Point(688, 34);
            this.btn_Ayuda.Name = "btn_Ayuda";
            this.btn_Ayuda.Size = new System.Drawing.Size(46, 47);
            this.btn_Ayuda.TabIndex = 128;
            this.btn_Ayuda.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_Ayuda.UseVisualStyleBackColor = false;
            // 
            // Mantenimiento_Vendedores
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(193)))), ((int)(((byte)(195)))));
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btn_Ayuda);
            this.Controls.Add(this.btnGenerarCodigo);
            this.Controls.Add(this.Txt_codEmpleado);
            this.Controls.Add(this.rdb_nodisponible);
            this.Controls.Add(this.rdb_disponible);
            this.Controls.Add(this.Lbl_estado);
            this.Controls.Add(this.Txt_ComisionVendedor);
            this.Controls.Add(this.Txt_nombreVendedor);
            this.Controls.Add(this.Txt_apellidoVendedor);
            this.Controls.Add(this.Lbl_ApellidoV);
            this.Controls.Add(this.Txt_cdigoVemdedor);
            this.Controls.Add(this.Lbl_nombreV);
            this.Controls.Add(this.Lbl_codigoV);
            this.Controls.Add(this.Lbl_empleado);
            this.Controls.Add(this.Lbl_Comision);
            this.Name = "Mantenimiento_Vendedores";
            this.Text = "Mantenimiento Vendedores";
            this.Load += new System.EventHandler(this.Mantenimiento_Vendedores_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnGenerarCodigo;
        private System.Windows.Forms.TextBox Txt_codEmpleado;
        private System.Windows.Forms.RadioButton rdb_nodisponible;
        private System.Windows.Forms.RadioButton rdb_disponible;
        private System.Windows.Forms.Label Lbl_estado;
        private System.Windows.Forms.TextBox Txt_ComisionVendedor;
        private System.Windows.Forms.TextBox Txt_nombreVendedor;
        private System.Windows.Forms.TextBox Txt_apellidoVendedor;
        private System.Windows.Forms.Label Lbl_ApellidoV;
        private System.Windows.Forms.TextBox Txt_cdigoVemdedor;
        private System.Windows.Forms.Label Lbl_nombreV;
        private System.Windows.Forms.Label Lbl_codigoV;
        private System.Windows.Forms.Label Lbl_empleado;
        private System.Windows.Forms.Label Lbl_Comision;
        private System.Windows.Forms.Button btn_Ayuda;
    }
}