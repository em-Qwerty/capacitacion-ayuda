﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Capacitación_Ayuda_2019
{
    public partial class Mantenimiento_Vendedores : Form
    {
        public Mantenimiento_Vendedores()
        {
            InitializeComponent();
        }

        private void Mantenimiento_Vendedores_Load(object sender, EventArgs e)
        {

        }
    }
}
