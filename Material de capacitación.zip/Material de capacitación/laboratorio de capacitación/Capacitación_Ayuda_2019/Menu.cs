﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Capacitación_Ayuda_2019
{
    public partial class Menu : Form
    {
        public Menu()
        {
            InitializeComponent();
        }

        private void Button2_Click(object sender, EventArgs e)
        {
            new Mantenimiento_Proveedores().Show();
        }

        private void Menu_Load(object sender, EventArgs e)
        {

        }

        private void Button1_Click(object sender, EventArgs e)
        {
            new Mantenimiento_Clientes().Show();
        }

        private void Button4_Click(object sender, EventArgs e)
        {
            new Mantenimiento_Cobradores().Show();
        }

        private void Button3_Click(object sender, EventArgs e)
        {
            new Mantenimiento_Vendedores().Show();
        }
    }
}
